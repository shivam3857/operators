# javascript
code of javascripts for me 
